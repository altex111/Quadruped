/*
 * debug.h
 *
 *  Created on: Nov 16, 2019
 *      Author: LORANT
*/
#pragma once

#define DEBUG_CODE_ACTIVE false
#define DEBUG_CODE_FIFO true
